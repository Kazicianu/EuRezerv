﻿namespace EuRezerv.Models.Base;


public class Client : BaseEntity
{
    public string ClientNume {  get; set; }

    public string ClientEmail { get; set; }

    public int ClientTelefon { get; set; }

    public ICollection<Rezervare> Rezervari { get; set; }
}
