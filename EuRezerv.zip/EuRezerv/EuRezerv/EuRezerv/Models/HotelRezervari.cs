﻿using EuRezerv.Models.Base;

namespace EuRezerv.Models
{
    public class HotelRezervari : BaseEntity
    {
        public Guid HotelId { get; set; }
        public Hotel Hotel { get; set; }

        public Guid RezervareId { get; set; }
        public Rezervare Rezervare { get; set; }
    }
}
