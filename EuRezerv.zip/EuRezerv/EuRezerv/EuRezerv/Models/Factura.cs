﻿using EuRezerv.Models.Base;

namespace EuRezerv.Models
{
    public class Factura : BaseEntity
    {
        public int FacturaValoare { get; set; }

        public Guid RezervareId { get; set; }
        public Rezervare Rezervare { get; set; }
    }
}
