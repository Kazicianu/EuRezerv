﻿namespace EuRezerv.Models.Enums
{
    public enum Roles
    {
        Admin,
        User
    }
}
