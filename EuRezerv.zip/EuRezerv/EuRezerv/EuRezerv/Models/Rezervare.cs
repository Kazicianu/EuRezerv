﻿using EuRezerv.Models.Base;
using System.ComponentModel.DataAnnotations.Schema;

namespace EuRezerv.Models
{
    public class Rezervare : BaseEntity

    {
        public DateTime Data { get; set; }
        public Guid ClientId { get; set; }

        public Client Client { get; set; } // One-to-Many cu Client
        public Factura Factura { get; set; } // One-to-One cu Factura
        public ICollection<HotelRezervari> HotelRezervari { get; set; } // Many-to-Many cu Hotel

       
    }
}
