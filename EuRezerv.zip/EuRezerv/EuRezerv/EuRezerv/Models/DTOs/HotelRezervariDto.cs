﻿namespace EuRezerv.Models.DTOs
{
    public class HotelRezervariDto
    {
        public Guid HotelId { get; set; }
        public Guid RezervareId { get; set; }
    }
}
