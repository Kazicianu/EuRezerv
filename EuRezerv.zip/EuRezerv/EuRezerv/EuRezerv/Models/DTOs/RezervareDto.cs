﻿namespace EuRezerv.Models.DTOs
{
    public class RezervareDto
    {
        public Guid Id { get; set; }
        public DateTime Data { get; set; }
        public Guid ClientId { get; set; }
    }
}
