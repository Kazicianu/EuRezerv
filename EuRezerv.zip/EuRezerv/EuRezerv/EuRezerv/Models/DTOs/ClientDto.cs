﻿namespace EuRezerv.Models.DTOs
{
    public class ClientDto
    {
        public Guid Id { get; set; }
        public string ClientNume { get; set; }

        public string ClientEmail { get; set; }

        public int ClientTelefon { get; set; }

    }
}
