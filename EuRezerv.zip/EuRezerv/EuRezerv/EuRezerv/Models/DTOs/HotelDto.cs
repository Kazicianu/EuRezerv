﻿namespace EuRezerv.Models.DTOs
{
    public class HotelDto
    {
        public Guid Id { get; set; }
        public string HotelNume { get; set; }
        public int HotelTelefon { get; set; }
        public int HotelLocatie { get; set; }
    }
}
