﻿namespace EuRezerv.Models.DTOs
{
    public class FacturaDto
    {
        public Guid Id { get; set; }
        public int FacturaValoare { get; set; }
    }
}
