﻿using EuRezerv.Models.Base;

namespace EuRezerv.Models
{
    public class Hotel : BaseEntity
    {
        public string HotelNume { get; set; }   
        public int HotelTelefon { get; set; }   
        public int HotelLocatie { get; set; }

        public ICollection<HotelRezervari> HotelRezervari { get; set; }
    }
}
