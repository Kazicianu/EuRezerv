﻿using AutoMapper;
using EuRezerv.Models;
using EuRezerv.Models.Base;
using EuRezerv.Models.DTOs;

namespace EuRezerv.Helpers
{
    public class MapperProfile : Profile
    {
        public MapperProfile()
        {
            
            CreateMap<Hotel, HotelDto>();
            CreateMap<HotelDto, Hotel>();

            CreateMap<Client, ClientDto>();
            CreateMap<ClientDto, Client>();

           
            CreateMap<Rezervare, RezervareDto>();
            CreateMap<RezervareDto, Rezervare>();

            CreateMap<Factura, FacturaDto>();
            CreateMap<FacturaDto, Factura>();

           
            CreateMap<HotelRezervari, HotelRezervariDto>();
            CreateMap<HotelRezervariDto, HotelRezervari>();

           
        }
    }
}
