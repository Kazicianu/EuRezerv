﻿using Microsoft.Extensions.DependencyInjection;
using EuRezerv.Repositories.HotelRepository;
using EuRezerv.Repositories.ClientRepository;
using EuRezerv.Repositories.RezervareRepository;
using EuRezerv.Repositories.FacturaRepository;
using EuRezerv.Repositories.HotelRezervariRepository;
using EuRezerv.Services.HotelService;
using EuRezerv.Services.ClientService;
using EuRezerv.Services.RezervareService;
using EuRezerv.Services.FacturaService;
using EuRezerv.Services.HotelRezervariService;


namespace EuRezerv.Helpers.Extensions
{
    public static class ServiceExtensions
    {
        // Repositories
        public static IServiceCollection AddHotelRepositories(this IServiceCollection services)
        {
            services.AddTransient<IHotelRepository, HotelRepository>();
            return services;
        }

        public static IServiceCollection AddClientRepositories(this IServiceCollection services)
        {
            services.AddTransient<IClientRepository, ClientRepository>();
            return services;
        }

        public static IServiceCollection AddRezervareRepositories(this IServiceCollection services)
        {
            services.AddTransient<IRezervareRepository, RezervareRepository>();
            return services;
        }

        public static IServiceCollection AddFacturaRepositories(this IServiceCollection services)
        {
            services.AddTransient<IFacturaRepository, FacturaRepository>();
            return services;
        }

        public static IServiceCollection AddHotelRezervariRepositories(this IServiceCollection services)
        {
            services.AddTransient<IHotelRezervariRepository, HotelRezervariRepository>();
            return services;
        }

      

        // Services
        public static IServiceCollection AddHotelServices(this IServiceCollection services)
        {
            services.AddTransient<IHotelService, HotelService>();
            return services;
        }

        public static IServiceCollection AddClientServices(this IServiceCollection services)
        {
            services.AddTransient<IClientService, ClientService>();
            return services;
        }

        public static IServiceCollection AddRezervareServices(this IServiceCollection services)
        {
            services.AddTransient<IRezervareService, RezervareService>();
            return services;
        }

        public static IServiceCollection AddFacturaServices(this IServiceCollection services)
        {
            services.AddTransient<IFacturaService, FacturaService>();
            return services;
        }

        public static IServiceCollection AddHotelRezervariServices(this IServiceCollection services)
        {
            services.AddTransient<IHotelRezervariService, HotelRezervariService>();
            return services;
        }

        
    }
}
