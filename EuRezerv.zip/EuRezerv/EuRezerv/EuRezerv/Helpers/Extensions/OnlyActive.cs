﻿namespace EuRezerv.Helpers.Extensions
{
    public static class OnlyActive
    {
    }
}
