﻿using EuRezerv.Models.Base;
using EuRezerv.Models;
using Microsoft.EntityFrameworkCore;

namespace EuRezerv.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<Hotel> Hotels { get; set; }
        public DbSet<Client> Clients { get; set; }
        public DbSet<Rezervare> Rezervari { get; set; }
        public DbSet<Factura> Facturi { get; set; }
        public DbSet<HotelRezervari> HotelRezervari { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
           
            modelBuilder.Entity<HotelRezervari>()
                .HasKey(hr => new { hr.HotelId, hr.RezervareId });

            modelBuilder.Entity<HotelRezervari>()
                .HasOne(hr => hr.Hotel)
            .WithMany(h => h.HotelRezervari)
                .HasForeignKey(hr => hr.HotelId);

            modelBuilder.Entity<HotelRezervari>()
                .HasOne(hr => hr.Rezervare)
                .WithMany(r => r.HotelRezervari)
                .HasForeignKey(hr => hr.RezervareId);

          
            modelBuilder.Entity<Client>()
                .HasMany(c => c.Rezervari)
                .WithOne(r => r.Client)
                .HasForeignKey(r => r.ClientId);

         
            modelBuilder.Entity<Rezervare>()
                .HasOne(r => r.Factura)
                .WithOne(f => f.Rezervare)
                .HasForeignKey<Factura>(f => f.RezervareId);

            base.OnModelCreating(modelBuilder);
        }
    }
}