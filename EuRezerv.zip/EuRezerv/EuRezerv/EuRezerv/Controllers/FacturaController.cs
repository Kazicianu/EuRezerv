﻿using EuRezerv.Models.DTOs;
using EuRezerv.Services.FacturaService;
using Microsoft.AspNetCore.Mvc;

namespace EuRezerv.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FacturaController : ControllerBase
    {
        private readonly IFacturaService _facturaService;

        public FacturaController(IFacturaService facturaService)
        {
            _facturaService = facturaService;
        }

        [HttpGet]
        public async Task<IActionResult> GetAllFacturi()
        {
            var facturi = await _facturaService.GetAllFacturi();
            return Ok(facturi);
        }

        [HttpGet("{facturaId}")]
        public async Task<IActionResult> GetFacturaById([FromRoute] Guid facturaId)
        {
            var factura = await _facturaService.GetFacturaById(facturaId);

            if (factura == null)
            {
                return NotFound();
            }

            return Ok(factura);
        }

        [HttpPost]
        public async Task<IActionResult> CreateFactura([FromBody] FacturaDto facturaDto)
        {
            await _facturaService.CreateFactura(facturaDto);
            return Ok();
        }

        [HttpPut("{facturaId}")]
        public async Task<IActionResult> UpdateFactura([FromRoute] Guid facturaId, [FromBody] FacturaDto facturaDto)
        {
            await _facturaService.UpdateFactura(facturaId, facturaDto);
            return Ok();
        }

        [HttpDelete("{facturaId}")]
        public async Task<IActionResult> DeleteFactura([FromRoute] Guid facturaId)
        {
            await _facturaService.DeleteFactura(facturaId);
            return Ok();
        }
    }
}
