﻿using EuRezerv.Models.DTOs;
using EuRezerv.Services.HotelService;
using Microsoft.AspNetCore.Mvc;

namespace EuRezerv.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class HotelController : ControllerBase
    {
        private readonly IHotelService _hotelService;

        public HotelController(IHotelService hotelService)
        {
            _hotelService = hotelService;
        }

        [HttpGet]
        public async Task<IActionResult> GetAllHotels()
        {
            var hotels = await _hotelService.GetAllHotels();
            return Ok(hotels);
        }

        [HttpGet("{hotelId}")]
        public async Task<IActionResult> GetHotelById([FromRoute] Guid hotelId)
        {
            var hotel = await _hotelService.GetHotelById(hotelId);

            if (hotel == null)
            {
                return NotFound();
            }

            return Ok(hotel);
        }

        [HttpPost]
        public async Task<IActionResult> CreateHotel([FromBody] HotelDto hotelDto)
        {
            await _hotelService.CreateHotel(hotelDto);
            return Ok();
        }

        [HttpPut("{hotelId}")]
        public async Task<IActionResult> UpdateHotel([FromRoute] Guid hotelId, [FromBody] HotelDto hotelDto)
        {
            await _hotelService.UpdateHotel(hotelId, hotelDto);
            return Ok();
        }

        [HttpDelete("{hotelId}")]
        public async Task<IActionResult> DeleteHotel([FromRoute] Guid hotelId)
        {
            await _hotelService.DeleteHotel(hotelId);
            return Ok();
        }
    }
}
