﻿using EuRezerv.Models.DTOs;
using EuRezerv.Services.HotelRezervariService;
using Microsoft.AspNetCore.Mvc;

namespace EuRezerv.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class HotelRezervariController : ControllerBase
    {
        private readonly IHotelRezervariService _hotelRezervariService;

        public HotelRezervariController(IHotelRezervariService hotelRezervariService)
        {
            _hotelRezervariService = hotelRezervariService;
        }

        [HttpGet]
        public async Task<IActionResult> GetAllHotelRezervari()
        {
            var hotelRezervari = await _hotelRezervariService.GetAllHotelRezervari();
            return Ok(hotelRezervari);
        }

        [HttpGet("{hotelRezervariId}")]
        public async Task<IActionResult> GetHotelRezervariById([FromRoute] Guid hotelRezervariId)
        {
            var hotelRezervari = await _hotelRezervariService.GetHotelRezervariById(hotelRezervariId);

            if (hotelRezervari == null)
            {
                return NotFound();
            }

            return Ok(hotelRezervari);
        }

        [HttpPost]
        public async Task<IActionResult> CreateHotelRezervari([FromBody] HotelRezervariDto hotelRezervariDto)
        {
            await _hotelRezervariService.CreateHotelRezervari(hotelRezervariDto);
            return Ok();
        }

        [HttpPut("{hotelRezervariId}")]
        public async Task<IActionResult> UpdateHotelRezervari([FromRoute] Guid hotelRezervariId, [FromBody] HotelRezervariDto hotelRezervariDto)
        {
            await _hotelRezervariService.UpdateHotelRezervari(hotelRezervariId, hotelRezervariDto);
            return Ok();
        }

        [HttpDelete("{hotelRezervariId}")]
        public async Task<IActionResult> DeleteHotelRezervari([FromRoute] Guid hotelRezervariId)
        {
            await _hotelRezervariService.DeleteHotelRezervari(hotelRezervariId);
            return Ok();
        }
    }
}
