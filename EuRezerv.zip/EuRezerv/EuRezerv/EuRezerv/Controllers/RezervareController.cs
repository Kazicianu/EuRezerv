﻿using EuRezerv.Models.DTOs;
using EuRezerv.Services.RezervareService;
using Microsoft.AspNetCore.Mvc;

namespace EuRezerv.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RezervareController : ControllerBase
    {
        private readonly IRezervareService _rezervareService;

        public RezervareController(IRezervareService rezervareService)
        {
            _rezervareService = rezervareService;
        }

        [HttpGet]
        public async Task<IActionResult> GetAllRezervari()
        {
            var rezervari = await _rezervareService.GetAllRezervari();
            return Ok(rezervari);
        }

        [HttpGet("{rezervareId}")]
        public async Task<IActionResult> GetRezervareById([FromRoute] Guid rezervareId)
        {
            var rezervare = await _rezervareService.GetRezervareById(rezervareId);

            if (rezervare == null)
            {
                return NotFound();
            }

            return Ok(rezervare);
        }

        [HttpPost]
        public async Task<IActionResult> CreateRezervare([FromBody] RezervareDto rezervareDto)
        {
            await _rezervareService.CreateRezervare(rezervareDto);
            return Ok();
        }

        [HttpPut("{rezervareId}")]
        public async Task<IActionResult> UpdateRezervare([FromRoute] Guid rezervareId, [FromBody] RezervareDto rezervareDto)
        {
            await _rezervareService.UpdateRezervare(rezervareId, rezervareDto);
            return Ok();
        }

        [HttpDelete("{rezervareId}")]
        public async Task<IActionResult> DeleteRezervare([FromRoute] Guid rezervareId)
        {
            await _rezervareService.DeleteRezervare(rezervareId);
            return Ok();
        }
    }
}
