﻿using EuRezerv.Models.DTOs;
using EuRezerv.Services.ClientService;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace EuRezerv.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ClientController : ControllerBase
    {
        private readonly IClientService _clientService;

        public ClientController(IClientService clientService)
        {
            _clientService = clientService;
        }

        [HttpGet]
        
        public async Task<IActionResult> GetAllClients([FromQuery] int pageNumber = 1, [FromQuery] int pageSize = 10)
        {
            var clients = await _clientService.GetAllClients(pageNumber, pageSize);
            return Ok(clients);
        }

        [HttpGet("{clientId}")]
        [Authorize(Roles = "Admin")] 
        public async Task<IActionResult> GetClientById([FromRoute] Guid clientId)
        {
            var client = await _clientService.GetClientById(clientId);

            if (client == null)
            {
                return NotFound();
            }

            return Ok(client);
        }

        [HttpPost]
        [Authorize(Roles = "Admin")] 
        public async Task<IActionResult> CreateClient([FromBody] ClientDto clientDto)
        {
            await _clientService.CreateClient(clientDto);
            return Ok();
        }

        [HttpPut("{clientId}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> UpdateClient([FromRoute] Guid clientId, [FromBody] ClientDto clientDto)
        {
            await _clientService.UpdateClient(clientId, clientDto);
            return Ok();
        }

        [HttpDelete("{clientId}")]
        [Authorize(Roles = "Admin")] 
        public async Task<IActionResult> DeleteClient([FromRoute] Guid clientId)
        {
            await _clientService.DeleteClient(clientId);
            return Ok();
        }
    }
}
