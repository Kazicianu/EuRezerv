﻿using EuRezerv.Data;
using EuRezerv.Helpers.Extensions; // Asigură-te că ai această clasă de extensie
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.OpenApi.Models;

var builder = WebApplication.CreateBuilder(args);

// Adăugare servicii pentru MVC
builder.Services.AddControllers();

// Configurare conexiune la baza de date SQL Server
builder.Services.AddDbContext<AppDbContext>(options =>
{
    options.UseSqlServer("Server=KAZI\\SQLEXPRESS;Database=EuRezerv;Trusted_Connection=True;TrustServerCertificate=True;");
});

// Configurare Swagger pentru documentație API
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo { Title = "EuRezerv API", Version = "v1" });
});

// Adăugare servicii pentru Repository și Service Layer
builder.Services.AddHotelRepositories()
               .AddHotelServices()
               .AddClientRepositories()
               .AddClientServices()
               .AddRezervareRepositories()
               .AddRezervareServices()
               .AddFacturaRepositories()
               .AddFacturaServices()
               .AddHotelRezervariRepositories()
               .AddHotelRezervariServices(); // Adaugă acest serviciu pentru HotelRezervari


builder.Services.AddAutoMapper(AppDomain.CurrentDomain.GetAssemblies());

builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.LoginPath = "/Account/Login";
        options.AccessDeniedPath = "/Account/AccessDenied";
    });

builder.Services.AddAuthorization(options =>
{
    options.AddPolicy("AdminOnly", policy => policy.RequireRole("Admin"));
    options.AddPolicy("UserOnly", policy => policy.RequireRole("User"));
});

builder.Services.AddCors(options =>
{
    options.AddDefaultPolicy(builder =>
    {
        builder.AllowAnyOrigin()
               .AllowAnyMethod()
               .AllowAnyHeader();
    });
});

var app = builder.Build();

// Seeding data - dacă este necesar
using (var scope = app.Services.CreateScope())
{
    var services = scope.ServiceProvider;
    var dbContext = services.GetRequiredService<AppDbContext>();
    // Poți adăuga cod pentru seeding aici, dacă este necesar
}

// Configurare Swagger
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI(c => c.SwaggerEndpoint("/swagger/v1/swagger.json", "EuRezerv API v1"));
}

// Configurare middleware
app.UseCors();
app.UseHttpsRedirection();
app.UseAuthentication(); // Adaugă middleware-ul pentru autentificare
app.UseAuthorization();  // Adaugă middleware-ul pentru autorizare
app.MapControllers();

app.Run();
