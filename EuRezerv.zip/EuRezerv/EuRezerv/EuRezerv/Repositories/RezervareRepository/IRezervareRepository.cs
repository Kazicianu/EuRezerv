﻿using EuRezerv.Models;
using EuRezerv.Repositories.GenericRepository;

namespace EuRezerv.Repositories.RezervareRepository
{
    public interface IRezervareRepository : IGenericRepository<Rezervare>
    {
    }
}
