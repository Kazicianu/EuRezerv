﻿using EuRezerv.Data;
using EuRezerv.Models;
using EuRezerv.Repositories.GenericRepository;

namespace EuRezerv.Repositories.RezervareRepository
{
    public class RezervareRepository : GenericRepository<Rezervare>, IRezervareRepository
    {
        public RezervareRepository(AppDbContext dbContext) : base(dbContext){ }
    }
}
