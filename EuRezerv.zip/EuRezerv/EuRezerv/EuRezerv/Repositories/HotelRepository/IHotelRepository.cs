﻿using EuRezerv.Models;
using EuRezerv.Repositories.GenericRepository;

namespace EuRezerv.Repositories.HotelRepository
{
    public interface IHotelRepository : IGenericRepository<Hotel>
    {
    }
}
