﻿using EuRezerv.Data;
using EuRezerv.Models;
using EuRezerv.Repositories.GenericRepository;

namespace EuRezerv.Repositories.HotelRepository
{
    public class HotelRepository : GenericRepository<Hotel>, IHotelRepository
    {
        public HotelRepository(AppDbContext appDbContext) : base(appDbContext)
        {
        }
    }
}
