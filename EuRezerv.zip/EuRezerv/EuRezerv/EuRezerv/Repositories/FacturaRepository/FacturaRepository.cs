﻿using EuRezerv.Data;
using EuRezerv.Models;
using EuRezerv.Repositories.GenericRepository;

namespace EuRezerv.Repositories.FacturaRepository
{
    public class FacturaRepository : GenericRepository<Factura> , IFacturaRepository
    {
        public FacturaRepository(AppDbContext dbContext): base(dbContext) { }
    }
}
