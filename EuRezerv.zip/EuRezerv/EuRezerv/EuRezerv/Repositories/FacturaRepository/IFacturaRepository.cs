﻿using EuRezerv.Models;
using EuRezerv.Repositories.GenericRepository;

namespace EuRezerv.Repositories.FacturaRepository
{
    public interface IFacturaRepository :IGenericRepository<Factura>
    {
    }
}
