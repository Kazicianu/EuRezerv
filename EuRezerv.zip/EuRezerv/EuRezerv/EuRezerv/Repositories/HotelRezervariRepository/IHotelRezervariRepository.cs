﻿using EuRezerv.Models;
using EuRezerv.Repositories.GenericRepository;

namespace EuRezerv.Repositories.HotelRezervariRepository
{
    public interface IHotelRezervariRepository : IGenericRepository<HotelRezervari>
    {
    }
}
