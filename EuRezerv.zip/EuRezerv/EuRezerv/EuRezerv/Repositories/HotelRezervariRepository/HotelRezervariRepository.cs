﻿using EuRezerv.Data;
using EuRezerv.Models;
using EuRezerv.Repositories.GenericRepository;

namespace EuRezerv.Repositories.HotelRezervariRepository
{
    public class HotelRezervariRepository : GenericRepository<HotelRezervari>, IHotelRezervariRepository
    {
        public HotelRezervariRepository(AppDbContext dbContext) : base(dbContext) { }
    }
}
