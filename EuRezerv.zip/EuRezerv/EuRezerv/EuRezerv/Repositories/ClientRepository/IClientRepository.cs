﻿using EuRezerv.Models.Base;
using EuRezerv.Repositories.GenericRepository;

namespace EuRezerv.Repositories.ClientRepository
{
    public interface IClientRepository : IGenericRepository<Client>
    {
    }
}
