﻿using EuRezerv.Data;
using EuRezerv.Models.Base;
using EuRezerv.Repositories.GenericRepository;

namespace EuRezerv.Repositories.ClientRepository
{
    public class ClientRepository : GenericRepository<Client>, IClientRepository
    {
        public ClientRepository(AppDbContext dbContext) : base(dbContext)
        {

        }
    }
}
