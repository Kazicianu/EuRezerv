﻿using AutoMapper;
using EuRezerv.Models;
using EuRezerv.Models.DTOs;
using EuRezerv.Repositories.HotelRepository;

namespace EuRezerv.Services.HotelService
{
    public class HotelService : IHotelService
    {
        private readonly IHotelRepository _hotelRepository;
        private readonly IMapper _mapper;

        public HotelService(IHotelRepository hotelRepository, IMapper mapper)
        {
            _hotelRepository = hotelRepository;
            _mapper = mapper;
        }

        public async Task<List<HotelDto>> GetAllHotels()
        {
            var hotels = await _hotelRepository.GetAllAsync();
            return _mapper.Map<List<HotelDto>>(hotels);
        }

        public async Task<HotelDto> GetHotelById(Guid hotelId)
        {
            var hotel = await _hotelRepository.FindByIdAsync(hotelId);
            return _mapper.Map<HotelDto>(hotel);
        }

        public async Task CreateHotel(HotelDto hotelDto)
        {
            var hotel = _mapper.Map<Hotel>(hotelDto);
            _hotelRepository.Create(hotel);
            await _hotelRepository.SaveAsync();
        }

        public async Task UpdateHotel(Guid hotelId, HotelDto hotelDto)
        {
            var existingHotel = await _hotelRepository.FindByIdAsync(hotelId);
            if (existingHotel == null)
            {
                throw new InvalidOperationException($"Hotelul cu ID-ul {hotelId} nu există.");
            }

            _mapper.Map(hotelDto, existingHotel);
            _hotelRepository.Update(existingHotel);
            await _hotelRepository.SaveAsync();
        }

        public async Task DeleteHotel(Guid hotelId)
        {
            var hotel = await _hotelRepository.FindByIdAsync(hotelId);
            if (hotel != null)
            {
                _hotelRepository.Delete(hotel);
                await _hotelRepository.SaveAsync();
            }
        }
    }
}
