﻿using EuRezerv.Models.DTOs;

namespace EuRezerv.Services.HotelService
{
    public interface IHotelService
    {
        Task<List<HotelDto>> GetAllHotels();
        Task<HotelDto> GetHotelById(Guid hotelId);
        Task CreateHotel(HotelDto hotelDto);
        Task UpdateHotel(Guid hotelId, HotelDto hotelDto);
        Task DeleteHotel(Guid hotelId);
    }
}
