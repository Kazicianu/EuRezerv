﻿using EuRezerv.Models.DTOs;

namespace EuRezerv.Services.HotelRezervariService
{
    public interface IHotelRezervariService
    {
        Task<List<HotelRezervariDto>> GetAllHotelRezervari();
        Task<HotelRezervariDto> GetHotelRezervariById(Guid hotelRezervariId);
        Task CreateHotelRezervari(HotelRezervariDto hotelRezervariDto);
        Task UpdateHotelRezervari(Guid hotelRezervariId, HotelRezervariDto hotelRezervariDto);
        Task DeleteHotelRezervari(Guid hotelRezervariId);
    }
}
