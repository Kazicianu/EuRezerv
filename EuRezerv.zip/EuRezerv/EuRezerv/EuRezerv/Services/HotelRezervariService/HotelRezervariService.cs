﻿using AutoMapper;
using EuRezerv.Models;
using EuRezerv.Models.DTOs;
using EuRezerv.Repositories.HotelRezervariRepository;
using EuRezerv.Services.HotelRezervariService;

namespace EuRezerv.Services.HotelRezervariService
{
    public class HotelRezervariService : IHotelRezervariService
    {
        private readonly IHotelRezervariRepository _hotelRezervariRepository;
        private readonly IMapper _mapper;

        public HotelRezervariService(IHotelRezervariRepository hotelRezervariRepository, IMapper mapper)
        {
            _hotelRezervariRepository = hotelRezervariRepository;
            _mapper = mapper;
        }

        public async Task<List<HotelRezervariDto>> GetAllHotelRezervari()
        {
            var hotelRezervari = await _hotelRezervariRepository.GetAllAsync();
            return _mapper.Map<List<HotelRezervariDto>>(hotelRezervari);
        }

        public async Task<HotelRezervariDto> GetHotelRezervariById(Guid hotelRezervariId)
        {
            var hotelRezervari = await _hotelRezervariRepository.FindByIdAsync(hotelRezervariId);
            return _mapper.Map<HotelRezervariDto>(hotelRezervari);
        }

        public async Task CreateHotelRezervari(HotelRezervariDto hotelRezervariDto)
        {
            var hotelRezervari = _mapper.Map<HotelRezervari>(hotelRezervariDto);
            _hotelRezervariRepository.Create(hotelRezervari);
            await _hotelRezervariRepository.SaveAsync();
        }

        public async Task UpdateHotelRezervari(Guid hotelRezervariId, HotelRezervariDto hotelRezervariDto)
        {
            var existingHotelRezervari = await _hotelRezervariRepository.FindByIdAsync(hotelRezervariId);
            if (existingHotelRezervari == null)
            {
                throw new InvalidOperationException($"HotelRezervari cu ID-ul {hotelRezervariId} nu există.");
            }

            _mapper.Map(hotelRezervariDto, existingHotelRezervari);
            _hotelRezervariRepository.Update(existingHotelRezervari);
            await _hotelRezervariRepository.SaveAsync();
        }

        public async Task DeleteHotelRezervari(Guid hotelRezervariId)
        {
            var hotelRezervari = await _hotelRezervariRepository.FindByIdAsync(hotelRezervariId);
            if (hotelRezervari != null)
            {
                _hotelRezervariRepository.Delete(hotelRezervari);
                await _hotelRezervariRepository.SaveAsync();
            }
        }
    }
}
