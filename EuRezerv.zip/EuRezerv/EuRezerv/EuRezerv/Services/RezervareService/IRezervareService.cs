﻿using EuRezerv.Models.DTOs;

namespace EuRezerv.Services.RezervareService
{
    public interface IRezervareService
    {
        Task<List<RezervareDto>> GetAllRezervari();
        Task<RezervareDto> GetRezervareById(Guid rezervareId);
        Task CreateRezervare(RezervareDto rezervareDto);
        Task UpdateRezervare(Guid rezervareId, RezervareDto rezervareDto);
        Task DeleteRezervare(Guid rezervareId);
    }
}
