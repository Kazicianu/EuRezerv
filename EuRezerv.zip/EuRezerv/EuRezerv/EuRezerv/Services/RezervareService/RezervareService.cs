﻿using AutoMapper;
using EuRezerv.Models;
using EuRezerv.Models.DTOs;
using EuRezerv.Repositories.RezervareRepository;

namespace EuRezerv.Services.RezervareService
{
    public class RezervareService : IRezervareService
    {
        private readonly IRezervareRepository _rezervareRepository;
        private readonly IMapper _mapper;

        public RezervareService(IRezervareRepository rezervareRepository, IMapper mapper)
        {
            _rezervareRepository = rezervareRepository;
            _mapper = mapper;
        }

        public async Task<List<RezervareDto>> GetAllRezervari()
        {
            var rezervari = await _rezervareRepository.GetAllAsync();
            return _mapper.Map<List<RezervareDto>>(rezervari);
        }

        public async Task<RezervareDto> GetRezervareById(Guid rezervareId)
        {
            var rezervare = await _rezervareRepository.FindByIdAsync(rezervareId);
            return _mapper.Map<RezervareDto>(rezervare);
        }

        public async Task CreateRezervare(RezervareDto rezervareDto)
        {
            var rezervare = _mapper.Map<Rezervare>(rezervareDto);
            _rezervareRepository.Create(rezervare);
            await _rezervareRepository.SaveAsync();
        }

        public async Task UpdateRezervare(Guid rezervareId, RezervareDto rezervareDto)
        {
            var existingRezervare = await _rezervareRepository.FindByIdAsync(rezervareId);
            if (existingRezervare == null)
            {
                throw new InvalidOperationException($"Rezervarea cu ID-ul {rezervareId} nu există.");
            }

            _mapper.Map(rezervareDto, existingRezervare);
            _rezervareRepository.Update(existingRezervare);
            await _rezervareRepository.SaveAsync();
        }

        public async Task DeleteRezervare(Guid rezervareId)
        {
            var rezervare = await _rezervareRepository.FindByIdAsync(rezervareId);
            if (rezervare != null)
            {
                _rezervareRepository.Delete(rezervare);
                await _rezervareRepository.SaveAsync();
            }
        }
    }
}
