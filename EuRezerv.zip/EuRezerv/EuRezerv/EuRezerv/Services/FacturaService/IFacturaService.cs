﻿using EuRezerv.Models.DTOs;

namespace EuRezerv.Services.FacturaService
{
    public interface IFacturaService
    {
        Task<List<FacturaDto>> GetAllFacturi();
        Task<FacturaDto> GetFacturaById(Guid facturaId);
        Task CreateFactura(FacturaDto facturaDto);
        Task UpdateFactura(Guid facturaId, FacturaDto facturaDto);
        Task DeleteFactura(Guid facturaId);
    }
}
