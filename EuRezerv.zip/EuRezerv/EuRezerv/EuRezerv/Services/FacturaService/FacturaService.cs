﻿using AutoMapper;
using EuRezerv.Models;
using EuRezerv.Models.DTOs;
using EuRezerv.Repositories.FacturaRepository;

namespace EuRezerv.Services.FacturaService
{
    public class FacturaService : IFacturaService
    {
        private readonly IFacturaRepository _facturaRepository;
        private readonly IMapper _mapper;

        public FacturaService(IFacturaRepository facturaRepository, IMapper mapper)
        {
            _facturaRepository = facturaRepository;
            _mapper = mapper;
        }

        public async Task<List<FacturaDto>> GetAllFacturi()
        {
            var facturi = await _facturaRepository.GetAllAsync();
            return _mapper.Map<List<FacturaDto>>(facturi);
        }

        public async Task<FacturaDto> GetFacturaById(Guid facturaId)
        {
            var factura = await _facturaRepository.FindByIdAsync(facturaId);
            return _mapper.Map<FacturaDto>(factura);
        }

        public async Task CreateFactura(FacturaDto facturaDto)
        {
            var factura = _mapper.Map<Factura>(facturaDto);
            _facturaRepository.Create(factura);
            await _facturaRepository.SaveAsync();
        }

        public async Task UpdateFactura(Guid facturaId, FacturaDto facturaDto)
        {
            var existingFactura = await _facturaRepository.FindByIdAsync(facturaId);
            if (existingFactura == null)
            {
                throw new InvalidOperationException($"Factura cu ID-ul {facturaId} nu există.");
            }

            _mapper.Map(facturaDto, existingFactura);
            _facturaRepository.Update(existingFactura);
            await _facturaRepository.SaveAsync();
        }

        public async Task DeleteFactura(Guid facturaId)
        {
            var factura = await _facturaRepository.FindByIdAsync(facturaId);
            if (factura != null)
            {
                _facturaRepository.Delete(factura);
                await _facturaRepository.SaveAsync();
            }
        }
    }
}
