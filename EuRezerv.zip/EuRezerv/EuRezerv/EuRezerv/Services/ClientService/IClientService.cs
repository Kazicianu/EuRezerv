﻿using EuRezerv.Models.DTOs;

namespace EuRezerv.Services.ClientService
{
    public interface IClientService
    {
        Task<IEnumerable<ClientDto>> GetAllClients(int pageNumber, int pageSize);
        Task<ClientDto> GetClientById(Guid clientId);
        Task CreateClient(ClientDto clientDto);
        Task UpdateClient(Guid clientId, ClientDto clientDto);
        Task DeleteClient(Guid clientId);
    }


}
