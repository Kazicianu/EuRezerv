﻿using AutoMapper;
using EuRezerv.Data;
using EuRezerv.Models;
using EuRezerv.Models.Base;
using EuRezerv.Models.DTOs;
using EuRezerv.Services.ClientService;
using Microsoft.EntityFrameworkCore;

public class ClientService : IClientService
{
    private readonly AppDbContext _context;
    private readonly IMapper _mapper;

    public ClientService(AppDbContext context, IMapper mapper)
    {
        _context = context;
        _mapper = mapper;
    }

    public async Task<IEnumerable<ClientDto>> GetAllClients(int pageNumber, int pageSize)
    {
        if (pageNumber < 1) pageNumber = 1;
        if (pageSize < 1) pageSize = 10;

        var clients = await _context.Clients
            .Skip((pageNumber - 1) * pageSize)
            .Take(pageSize)
            .ToListAsync();

        return _mapper.Map<IEnumerable<ClientDto>>(clients);
    }

    public async Task<ClientDto> GetClientById(Guid clientId)
    {
        var client = await _context.Clients.FindAsync(clientId);
        return _mapper.Map<ClientDto>(client);
    }

    public async Task CreateClient(ClientDto clientDto)
    {
        var client = _mapper.Map<Client>(clientDto);
        _context.Clients.Add(client);
        await _context.SaveChangesAsync();
    }

    public async Task UpdateClient(Guid clientId, ClientDto clientDto)
    {
        var client = await _context.Clients.FindAsync(clientId);
        if (client == null) throw new KeyNotFoundException("Client not found");

        _mapper.Map(clientDto, client);
        _context.Clients.Update(client);
        await _context.SaveChangesAsync();
    }

    public async Task DeleteClient(Guid clientId)
    {
        var client = await _context.Clients.FindAsync(clientId);
        if (client == null) throw new KeyNotFoundException("Client not found");

        _context.Clients.Remove(client);
        await _context.SaveChangesAsync();
    }
}
